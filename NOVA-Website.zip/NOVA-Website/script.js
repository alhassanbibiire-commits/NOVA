const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');

menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  });
});

const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(element => revealObserver.observe(element));

document.getElementById('year').textContent = new Date().getFullYear();

// Give the demo contact button a helpful local response.
document.querySelector('.button-light').addEventListener('click', event => {
  if (event.currentTarget.getAttribute('href') === 'mailto:hello@nova.example') {
    event.preventDefault();
    const toast = document.querySelector('.toast');
    toast.textContent = 'Demo email: replace hello@nova.example with your real address.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3200);
  }
});
